(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/components/about-section.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// purbaya-analytics/components/about-section.tsx
__turbopack_context__.s([
    "default",
    ()=>AboutSection
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
"use client";
;
;
function AboutSection() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(21);
    if ($[0] !== "7c43e1d6e83101c2aadd8849c4b4f160323f9a6a3fcc83df5457742302365379") {
        for(let $i = 0; $i < 21; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "7c43e1d6e83101c2aadd8849c4b4f160323f9a6a3fcc83df5457742302365379";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [
            {
                name: "Python",
                icon: "\uD83D\uDC0D",
                category: "Backend"
            },
            {
                name: "Pandas",
                icon: "\uD83D\uDC3C",
                category: "Data Processing"
            },
            {
                name: "NLTK",
                icon: "\uD83D\uDCDA",
                category: "NLP"
            },
            {
                name: "Sastrawi",
                icon: "\uD83C\uDDEE\uD83C\uDDE9",
                category: "Stemming"
            },
            {
                name: "Scikit-learn",
                icon: "\uD83E\uDD16",
                category: "ML"
            },
            {
                name: "Next.js",
                icon: "\u269B\uFE0F",
                category: "Frontend"
            },
            {
                name: "Tailwind CSS",
                icon: "\uD83C\uDFA8",
                category: "Styling"
            },
            {
                name: "Chart.js",
                icon: "\uD83D\uDCC8",
                category: "Visualization"
            }
        ];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const techStack = t0;
    let t1;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = [
            {
                icon: "\uD83D\uDCCA",
                title: "Sentiment Analysis",
                description: "Advanced keyword-based analysis with emoji fusion and TextBlob fallback"
            },
            {
                icon: "\uD83C\uDFAF",
                title: "Topic Modeling",
                description: "LDA-based topic extraction identifying 5 key discussion themes"
            },
            {
                icon: "\uD83D\uDCAD",
                title: "Emotion Detection",
                description: "7-category emotion classification: trust, joy, hope, sadness, fear, anger, happiness"
            },
            {
                icon: "\u2601\uFE0F",
                title: "Word Cloud",
                description: "Visual representation of most frequent terms across all sentiments"
            }
        ];
        $[2] = t1;
    } else {
        t1 = $[2];
    }
    const features = t1;
    let t2;
    let t3;
    let t4;
    let t5;
    let t6;
    if ($[3] === Symbol.for("react.memo_cache_sentinel")) {
        t2 = {
            paddingBottom: "48px"
        };
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                marginBottom: "48px"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        display: "inline-flex",
                        alignItems: "center",
                        gap: "8px",
                        padding: "8px 16px",
                        borderRadius: "20px",
                        background: "rgba(0, 212, 255, 0.1)",
                        border: "1px solid rgba(0, 212, 255, 0.3)",
                        marginBottom: "16px"
                    },
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        style: {
                            fontSize: "14px",
                            fontWeight: "600",
                            color: "#00d4ff"
                        },
                        children: "ℹ️ ABOUT PROJECT"
                    }, void 0, false, {
                        fileName: "[project]/components/about-section.tsx",
                        lineNumber: 97,
                        columnNumber: 10
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/components/about-section.tsx",
                    lineNumber: 88,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    style: {
                        fontSize: "42px",
                        fontWeight: "800",
                        lineHeight: "1.2",
                        marginBottom: "12px",
                        background: "linear-gradient(135deg, #ffffff 0%, #8892b0 100%)",
                        WebkitBackgroundClip: "text",
                        WebkitTextFillColor: "transparent"
                    },
                    children: "Purbaya Effect Analytics"
                }, void 0, false, {
                    fileName: "[project]/components/about-section.tsx",
                    lineNumber: 101,
                    columnNumber: 41
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    style: {
                        fontSize: "16px",
                        color: "#8892b0",
                        lineHeight: "1.6"
                    },
                    children: "A comprehensive sentiment analysis dashboard exploring public discourse around Indonesia's economic leadership"
                }, void 0, false, {
                    fileName: "[project]/components/about-section.tsx",
                    lineNumber: 109,
                    columnNumber: 39
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/about-section.tsx",
            lineNumber: 86,
            columnNumber: 10
        }, this);
        t4 = {
            background: "linear-gradient(135deg, rgba(30, 33, 57, 0.4) 0%, rgba(37, 42, 74, 0.2) 100%)",
            backdropFilter: "blur(10px)",
            border: "1px solid rgba(255, 255, 255, 0.04)",
            borderRadius: "20px",
            padding: "40px",
            marginBottom: "32px"
        };
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
            style: {
                fontSize: "20px",
                fontWeight: "700",
                color: "#ffffff",
                display: "flex",
                alignItems: "center",
                gap: "12px",
                marginBottom: "20px"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    style: {
                        width: "4px",
                        height: "24px",
                        background: "linear-gradient(to bottom, #00d4ff, #7b2ff7)",
                        borderRadius: "2px",
                        display: "inline-block"
                    }
                }, void 0, false, {
                    fileName: "[project]/components/about-section.tsx",
                    lineNumber: 130,
                    columnNumber: 8
                }, this),
                "Project Overview"
            ]
        }, void 0, true, {
            fileName: "[project]/components/about-section.tsx",
            lineNumber: 122,
            columnNumber: 10
        }, this);
        t6 = {
            fontSize: "15px",
            color: "#a0aec0",
            lineHeight: "1.8",
            marginBottom: "16px"
        };
        $[3] = t2;
        $[4] = t3;
        $[5] = t4;
        $[6] = t5;
        $[7] = t6;
    } else {
        t2 = $[3];
        t3 = $[4];
        t4 = $[5];
        t5 = $[6];
        t6 = $[7];
    }
    let t7;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
            style: {
                color: "#00d4ff"
            },
            children: "2,631 YouTube comments"
        }, void 0, false, {
            fileName: "[project]/components/about-section.tsx",
            lineNumber: 157,
            columnNumber: 10
        }, this);
        $[8] = t7;
    } else {
        t7 = $[8];
    }
    let t8;
    if ($[9] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
            style: {
                color: "#00d4ff"
            },
            children: "Purbaya"
        }, void 0, false, {
            fileName: "[project]/components/about-section.tsx",
            lineNumber: 166,
            columnNumber: 10
        }, this);
        $[9] = t8;
    } else {
        t8 = $[9];
    }
    let t10;
    let t11;
    let t12;
    let t13;
    let t14;
    let t15;
    let t16;
    let t9;
    if ($[10] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: t4,
            children: [
                t5,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    style: t6,
                    children: [
                        "This dashboard presents a deep-dive analysis of ",
                        t7,
                        " discussing",
                        " ",
                        t8,
                        " and",
                        " ",
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                            style: {
                                color: "#00d4ff"
                            },
                            children: "Sri Mulyani"
                        }, void 0, false, {
                            fileName: "[project]/components/about-section.tsx",
                            lineNumber: 182,
                            columnNumber: 125
                        }, this),
                        " in the context of Indonesia's economic discourse. Using advanced NLP techniques and sentiment analysis, we uncover public sentiment, emotional responses, and key discussion topics."
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/about-section.tsx",
                    lineNumber: 182,
                    columnNumber: 30
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        display: "grid",
                        gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
                        gap: "16px",
                        marginTop: "24px"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                padding: "16px",
                                background: "rgba(0, 212, 255, 0.05)",
                                border: "1px solid rgba(0, 212, 255, 0.2)",
                                borderRadius: "12px"
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    style: {
                                        fontSize: "24px",
                                        fontWeight: "800",
                                        color: "#00d4ff",
                                        marginBottom: "4px"
                                    },
                                    children: "2,631"
                                }, void 0, false, {
                                    fileName: "[project]/components/about-section.tsx",
                                    lineNumber: 194,
                                    columnNumber: 12
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    style: {
                                        fontSize: "12px",
                                        color: "#8892b0",
                                        textTransform: "uppercase",
                                        letterSpacing: "1px"
                                    },
                                    children: "Comments Analyzed"
                                }, void 0, false, {
                                    fileName: "[project]/components/about-section.tsx",
                                    lineNumber: 199,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/about-section.tsx",
                            lineNumber: 189,
                            columnNumber: 10
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                padding: "16px",
                                background: "rgba(123, 47, 247, 0.05)",
                                border: "1px solid rgba(123, 47, 247, 0.2)",
                                borderRadius: "12px"
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    style: {
                                        fontSize: "24px",
                                        fontWeight: "800",
                                        color: "#7b2ff7",
                                        marginBottom: "4px"
                                    },
                                    children: "5"
                                }, void 0, false, {
                                    fileName: "[project]/components/about-section.tsx",
                                    lineNumber: 209,
                                    columnNumber: 12
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    style: {
                                        fontSize: "12px",
                                        color: "#8892b0",
                                        textTransform: "uppercase",
                                        letterSpacing: "1px"
                                    },
                                    children: "Topic Models"
                                }, void 0, false, {
                                    fileName: "[project]/components/about-section.tsx",
                                    lineNumber: 214,
                                    columnNumber: 21
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/about-section.tsx",
                            lineNumber: 204,
                            columnNumber: 43
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: {
                                padding: "16px",
                                background: "rgba(255, 0, 110, 0.05)",
                                border: "1px solid rgba(255, 0, 110, 0.2)",
                                borderRadius: "12px"
                            },
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    style: {
                                        fontSize: "24px",
                                        fontWeight: "800",
                                        color: "#ff006e",
                                        marginBottom: "4px"
                                    },
                                    children: "7"
                                }, void 0, false, {
                                    fileName: "[project]/components/about-section.tsx",
                                    lineNumber: 224,
                                    columnNumber: 12
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    style: {
                                        fontSize: "12px",
                                        color: "#8892b0",
                                        textTransform: "uppercase",
                                        letterSpacing: "1px"
                                    },
                                    children: "Emotion Categories"
                                }, void 0, false, {
                                    fileName: "[project]/components/about-section.tsx",
                                    lineNumber: 229,
                                    columnNumber: 21
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/about-section.tsx",
                            lineNumber: 219,
                            columnNumber: 38
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/about-section.tsx",
                    lineNumber: 184,
                    columnNumber: 217
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/about-section.tsx",
            lineNumber: 182,
            columnNumber: 10
        }, this);
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                marginBottom: "32px"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    style: {
                        fontSize: "20px",
                        fontWeight: "700",
                        color: "#ffffff",
                        display: "flex",
                        alignItems: "center",
                        gap: "12px",
                        marginBottom: "24px"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            style: {
                                width: "4px",
                                height: "24px",
                                background: "linear-gradient(to bottom, #00d4ff, #7b2ff7)",
                                borderRadius: "2px",
                                display: "inline-block"
                            }
                        }, void 0, false, {
                            fileName: "[project]/components/about-section.tsx",
                            lineNumber: 245,
                            columnNumber: 10
                        }, this),
                        "Key Features"
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/about-section.tsx",
                    lineNumber: 237,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        display: "grid",
                        gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
                        gap: "20px"
                    },
                    children: features.map(_AboutSectionFeaturesMap)
                }, void 0, false, {
                    fileName: "[project]/components/about-section.tsx",
                    lineNumber: 251,
                    columnNumber: 31
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/about-section.tsx",
            lineNumber: 235,
            columnNumber: 11
        }, this);
        t11 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                background: "linear-gradient(135deg, rgba(30, 33, 57, 0.4) 0%, rgba(37, 42, 74, 0.2) 100%)",
                backdropFilter: "blur(10px)",
                border: "1px solid rgba(255, 255, 255, 0.04)",
                borderRadius: "20px",
                padding: "40px",
                marginBottom: "32px"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    style: {
                        fontSize: "20px",
                        fontWeight: "700",
                        color: "#ffffff",
                        display: "flex",
                        alignItems: "center",
                        gap: "12px",
                        marginBottom: "24px"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            style: {
                                width: "4px",
                                height: "24px",
                                background: "linear-gradient(to bottom, #00d4ff, #7b2ff7)",
                                borderRadius: "2px",
                                display: "inline-block"
                            }
                        }, void 0, false, {
                            fileName: "[project]/components/about-section.tsx",
                            lineNumber: 271,
                            columnNumber: 10
                        }, this),
                        "Methodology"
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/about-section.tsx",
                    lineNumber: 263,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        display: "flex",
                        flexDirection: "column",
                        gap: "16px"
                    },
                    children: [
                        {
                            label: "Data Source",
                            value: "2,631 comments from YouTube video(s) discussing Indonesian economic policies"
                        },
                        {
                            label: "Preprocessing",
                            value: "Lowercase conversion, stopword removal (custom Indonesian list), stemming using Sastrawi"
                        },
                        {
                            label: "Sentiment Analysis",
                            value: "Hybrid approach: keyword-based detection + emoji analysis + TextBlob fallback"
                        },
                        {
                            label: "Topic Modeling",
                            value: "Latent Dirichlet Allocation (LDA) with 5 optimized topics"
                        },
                        {
                            label: "Emotion Detection",
                            value: "7-category classification: trust, joy, hope, sadness, fear, anger, happiness"
                        }
                    ].map(_AboutSectionAnonymous)
                }, void 0, false, {
                    fileName: "[project]/components/about-section.tsx",
                    lineNumber: 277,
                    columnNumber: 30
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/about-section.tsx",
            lineNumber: 256,
            columnNumber: 11
        }, this);
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                marginBottom: "32px"
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    style: {
                        fontSize: "20px",
                        fontWeight: "700",
                        color: "#ffffff",
                        display: "flex",
                        alignItems: "center",
                        gap: "12px",
                        marginBottom: "24px"
                    },
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            style: {
                                width: "4px",
                                height: "24px",
                                background: "linear-gradient(to bottom, #00d4ff, #7b2ff7)",
                                borderRadius: "2px",
                                display: "inline-block"
                            }
                        }, void 0, false, {
                            fileName: "[project]/components/about-section.tsx",
                            lineNumber: 307,
                            columnNumber: 10
                        }, this),
                        "Technology Stack"
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/about-section.tsx",
                    lineNumber: 299,
                    columnNumber: 8
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        display: "grid",
                        gridTemplateColumns: "repeat(auto-fill, minmax(140px, 1fr))",
                        gap: "16px"
                    },
                    children: techStack.map(_AboutSectionTechStackMap)
                }, void 0, false, {
                    fileName: "[project]/components/about-section.tsx",
                    lineNumber: 313,
                    columnNumber: 35
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/about-section.tsx",
            lineNumber: 297,
            columnNumber: 11
        }, this);
        t13 = {
            background: "linear-gradient(135deg, rgba(30, 33, 57, 0.4) 0%, rgba(37, 42, 74, 0.2) 100%)",
            backdropFilter: "blur(10px)",
            border: "1px solid rgba(255, 255, 255, 0.04)",
            borderRadius: "20px",
            padding: "32px",
            textAlign: "center"
        };
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                fontSize: "32px",
                marginBottom: "12px"
            },
            children: "❤️"
        }, void 0, false, {
            fileName: "[project]/components/about-section.tsx",
            lineNumber: 326,
            columnNumber: 11
        }, this);
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            style: {
                fontSize: "18px",
                fontWeight: "700",
                color: "#ffffff",
                marginBottom: "8px"
            },
            children: "Built for Transparency"
        }, void 0, false, {
            fileName: "[project]/components/about-section.tsx",
            lineNumber: 330,
            columnNumber: 11
        }, this);
        t16 = {
            fontSize: "14px",
            color: "#8892b0",
            lineHeight: "1.6",
            marginBottom: "16px"
        };
        $[10] = t10;
        $[11] = t11;
        $[12] = t12;
        $[13] = t13;
        $[14] = t14;
        $[15] = t15;
        $[16] = t16;
        $[17] = t9;
    } else {
        t10 = $[10];
        t11 = $[11];
        t12 = $[12];
        t13 = $[13];
        t14 = $[14];
        t15 = $[15];
        t16 = $[16];
        t9 = $[17];
    }
    let t17;
    let t18;
    if ($[18] === Symbol.for("react.memo_cache_sentinel")) {
        t17 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            style: t16,
            children: [
                "Inspired by data journalism and NLP for social good.",
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("br", {}, void 0, false, {
                    fileName: "[project]/components/about-section.tsx",
                    lineNumber: 363,
                    columnNumber: 78
                }, this),
                "Empowering informed discourse through data-driven insights."
            ]
        }, void 0, true, {
            fileName: "[project]/components/about-section.tsx",
            lineNumber: 363,
            columnNumber: 11
        }, this);
        t18 = {
            paddingTop: "20px",
            borderTop: "1px solid rgba(255, 255, 255, 0.06)",
            fontSize: "12px",
            color: "#6b7280"
        };
        $[18] = t17;
        $[19] = t18;
    } else {
        t17 = $[18];
        t18 = $[19];
    }
    let t19;
    if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: t2,
            children: [
                t3,
                t9,
                t10,
                t11,
                t12,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: t13,
                    children: [
                        t14,
                        t15,
                        t17,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            style: t18,
                            children: [
                                "© ",
                                new Date().getFullYear(),
                                " • Purbaya Effect Analytics • All data anonymized for privacy"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/about-section.tsx",
                            lineNumber: 378,
                            columnNumber: 82
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/about-section.tsx",
                    lineNumber: 378,
                    columnNumber: 50
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/about-section.tsx",
            lineNumber: 378,
            columnNumber: 11
        }, this);
        $[20] = t19;
    } else {
        t19 = $[20];
    }
    return t19;
}
_c = AboutSection;
function _AboutSectionTechStackMap(tech, idx_1) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            background: "linear-gradient(135deg, rgba(30, 33, 57, 0.6) 0%, rgba(37, 42, 74, 0.4) 100%)",
            border: "1px solid rgba(255, 255, 255, 0.06)",
            borderRadius: "12px",
            padding: "20px",
            textAlign: "center",
            transition: "all 0.3s ease",
            cursor: "pointer"
        },
        onMouseEnter: _AboutSectionTechStackMapDivOnMouseEnter,
        onMouseLeave: _AboutSectionTechStackMapDivOnMouseLeave,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    fontSize: "32px",
                    marginBottom: "8px"
                },
                children: tech.icon
            }, void 0, false, {
                fileName: "[project]/components/about-section.tsx",
                lineNumber: 394,
                columnNumber: 118
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    fontSize: "14px",
                    fontWeight: "600",
                    color: "#ffffff",
                    marginBottom: "4px"
                },
                children: tech.name
            }, void 0, false, {
                fileName: "[project]/components/about-section.tsx",
                lineNumber: 397,
                columnNumber: 25
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    fontSize: "11px",
                    color: "#8892b0",
                    textTransform: "uppercase",
                    letterSpacing: "0.5px"
                },
                children: tech.category
            }, void 0, false, {
                fileName: "[project]/components/about-section.tsx",
                lineNumber: 402,
                columnNumber: 25
            }, this)
        ]
    }, idx_1, true, {
        fileName: "[project]/components/about-section.tsx",
        lineNumber: 386,
        columnNumber: 10
    }, this);
}
function _AboutSectionTechStackMapDivOnMouseLeave(e_2) {
    e_2.currentTarget.style.borderColor = "rgba(255, 255, 255, 0.06)";
    e_2.currentTarget.style.transform = "translateY(0)";
}
function _AboutSectionTechStackMapDivOnMouseEnter(e_1) {
    e_1.currentTarget.style.borderColor = "rgba(0, 212, 255, 0.3)";
    e_1.currentTarget.style.transform = "translateY(-4px)";
}
function _AboutSectionAnonymous(item, idx_0) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            padding: "16px 20px",
            background: "rgba(0, 212, 255, 0.03)",
            border: "1px solid rgba(255, 255, 255, 0.04)",
            borderLeft: "3px solid #00d4ff",
            borderRadius: "8px"
        },
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    fontSize: "12px",
                    fontWeight: "700",
                    color: "#00d4ff",
                    textTransform: "uppercase",
                    letterSpacing: "1px",
                    marginBottom: "6px"
                },
                children: item.label
            }, void 0, false, {
                fileName: "[project]/components/about-section.tsx",
                lineNumber: 424,
                columnNumber: 6
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    fontSize: "14px",
                    color: "#a0aec0",
                    lineHeight: "1.6"
                },
                children: item.value
            }, void 0, false, {
                fileName: "[project]/components/about-section.tsx",
                lineNumber: 431,
                columnNumber: 26
            }, this)
        ]
    }, idx_0, true, {
        fileName: "[project]/components/about-section.tsx",
        lineNumber: 418,
        columnNumber: 10
    }, this);
}
function _AboutSectionFeaturesMap(feature, idx) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        style: {
            background: "linear-gradient(135deg, rgba(30, 33, 57, 0.6) 0%, rgba(37, 42, 74, 0.4) 100%)",
            border: "1px solid rgba(255, 255, 255, 0.06)",
            borderRadius: "16px",
            padding: "24px",
            transition: "all 0.3s ease"
        },
        onMouseEnter: _AboutSectionFeaturesMapDivOnMouseEnter,
        onMouseLeave: _AboutSectionFeaturesMapDivOnMouseLeave,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    fontSize: "32px",
                    marginBottom: "12px"
                },
                children: feature.icon
            }, void 0, false, {
                fileName: "[project]/components/about-section.tsx",
                lineNumber: 444,
                columnNumber: 116
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                style: {
                    fontSize: "16px",
                    fontWeight: "700",
                    color: "#ffffff",
                    marginBottom: "8px"
                },
                children: feature.title
            }, void 0, false, {
                fileName: "[project]/components/about-section.tsx",
                lineNumber: 447,
                columnNumber: 28
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                style: {
                    fontSize: "14px",
                    color: "#8892b0",
                    lineHeight: "1.6"
                },
                children: feature.description
            }, void 0, false, {
                fileName: "[project]/components/about-section.tsx",
                lineNumber: 452,
                columnNumber: 28
            }, this)
        ]
    }, idx, true, {
        fileName: "[project]/components/about-section.tsx",
        lineNumber: 438,
        columnNumber: 10
    }, this);
}
function _AboutSectionFeaturesMapDivOnMouseLeave(e_0) {
    e_0.currentTarget.style.borderColor = "rgba(255, 255, 255, 0.06)";
    e_0.currentTarget.style.transform = "translateY(0)";
    e_0.currentTarget.style.boxShadow = "none";
}
function _AboutSectionFeaturesMapDivOnMouseEnter(e) {
    e.currentTarget.style.borderColor = "rgba(0, 212, 255, 0.3)";
    e.currentTarget.style.transform = "translateY(-4px)";
    e.currentTarget.style.boxShadow = "0 12px 24px rgba(0, 212, 255, 0.1)";
}
var _c;
__turbopack_context__.k.register(_c, "AboutSection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=components_about-section_tsx_c6e20e9c._.js.map