(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_818c16af._.js",
  "static/chunks/node_modules_189aa31f._.js",
  "static/chunks/src_app_dashboard_715f76ee.css"
],
    source: "dynamic"
});
