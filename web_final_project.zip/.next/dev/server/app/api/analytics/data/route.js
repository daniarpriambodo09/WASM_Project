var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/analytics/data/route.js")
R.c("server/chunks/node_modules_next_9ebad3d5._.js")
R.c("server/chunks/node_modules_@supabase_storage-js_dist_module_829f4f3c._.js")
R.c("server/chunks/node_modules_@supabase_auth-js_dist_module_02e1b12e._.js")
R.c("server/chunks/node_modules_d4538731._.js")
R.c("server/chunks/[root-of-the-server]__da1148a9._.js")
R.c("server/chunks/_next-internal_server_app_api_analytics_data_route_actions_f7137ea0.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/analytics/data/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/app/api/analytics/data/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
