module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/src/lib/supabase.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "supabase",
    ()=>supabase
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/module/index.js [app-route] (ecmascript) <locals>");
;
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://bmizrtfzvqxatxvlkunt.supabase.co";
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJtaXpydGZ6dnF4YXR4dmxrdW50Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjM5MjM5NTgsImV4cCI6MjA3OTQ5OTk1OH0.lkbb-fw470AyiidYu153KLAMLP3fFqc3qLDeA_KSa3s";
const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(supabaseUrl, supabaseAnonKey);
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/app/api/analytics/data/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/supabase.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
;
;
async function GET() {
    try {
        const { data, error } = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["supabase"].from("data_analisis_wasm").select("*");
        if (error) {
            console.error("Supabase error:", error);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: error.message
            }, {
                status: 500
            });
        }
        console.log("[v0] Raw data from Supabase:", data?.length, "records");
        const transformedData = transformAnalyticsData(data || []);
        console.log("[v0] Transformed data:", {
            keywords: transformedData.keywords.length,
            topics: transformedData.topics.length
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(transformedData);
    } catch (error) {
        console.error("API error:", error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "Failed to fetch analytics data"
        }, {
            status: 500
        });
    }
}
function transformAnalyticsData(rawData) {
    const totalComments = rawData.length;
    if (rawData.length > 0) {
        console.log("[v0] First record sample:", JSON.stringify(rawData[0], null, 2));
        console.log("[v0] All columns:", Object.keys(rawData[0]));
    }
    // Calculate average comment length
    const avgLength = rawData.reduce((sum, item)=>{
        const textLength = (item.processed_comment || item.raw_comment || "").toString().length;
        return sum + textLength;
    }, 0) / Math.max(totalComments, 1);
    // Count sentiments
    const sentimentCounts = {
        positive: 0,
        neutral: 0,
        negative: 0
    };
    rawData.forEach((item)=>{
        const sentiment = (item.sentiment || "neutral").toLowerCase();
        if (sentiment in sentimentCounts) {
            sentimentCounts[sentiment]++;
        }
    });
    // Count emotions
    const emotionCounts = {};
    rawData.forEach((item)=>{
        const emotion = (item.emotion || "").toLowerCase().trim();
        if (emotion) {
            emotionCounts[emotion] = (emotionCounts[emotion] || 0) + 1;
        }
    });
    const keywordCounts = {};
    rawData.forEach((item)=>{
        const commentText = item.processed_comment || item.raw_comment || "";
        if (commentText) {
            const words = commentText.toString().toLowerCase().split(/\s+/).filter((w)=>w.length > 2);
            words.forEach((word)=>{
                const cleaned = word.replace(/[^\w]/g, "");
                if (cleaned.length > 2) {
                    keywordCounts[cleaned] = (keywordCounts[cleaned] || 0) + 1;
                }
            });
        }
    });
    console.log("[v0] Keywords found:", Object.keys(keywordCounts).length, keywordCounts);
    const topicCounts = {};
    rawData.forEach((item)=>{
        const topicId = item.dominant_topic;
        if (topicId !== null && topicId !== undefined && !isNaN(topicId)) {
            topicCounts[topicId] = (topicCounts[topicId] || 0) + 1;
        }
    });
    console.log("[v0] Topics found:", Object.keys(topicCounts).length, topicCounts);
    // Transform sentiment data
    const sentimentData = {};
    Object.entries(sentimentCounts).forEach(([key, count])=>{
        sentimentData[key] = {
            count,
            pct: Math.round(count / totalComments * 10000) / 100
        };
    });
    // Transform emotion data
    const emotionData = {};
    Object.entries(emotionCounts).forEach(([key, count])=>{
        emotionData[key] = {
            count,
            pct: Math.round(count / totalComments * 10000) / 100
        };
    });
    const stopWords = new Set([
        "yang",
        "dan",
        "apa",
        "ini",
        "itu",
        "ada",
        "dari",
        "ke",
        "di",
        "untuk",
        "dengan",
        "atau"
    ]);
    const topKeywords = Object.entries(keywordCounts).filter(([kw])=>!stopWords.has(kw)).sort(([, a], [, b])=>b - a).slice(0, 10).map(([kw, count])=>[
            kw,
            count
        ]);
    const topicKeywordsMap = {
        0: [
            "purbaya",
            "rakyat",
            "sri",
            "mulyani",
            "pajak",
            "pro",
            "ekonomi",
            "negara",
            "mau",
            "tim"
        ],
        1: [
            "purbaya",
            "bijak",
            "apa",
            "uang",
            "beliau",
            "ekonomi",
            "semua",
            "tri",
            "indonesia",
            "baru"
        ],
        2: [
            "rokok",
            "naik",
            "cukai",
            "purbaya",
            "rakyat",
            "gak",
            "kalau",
            "bukan",
            "turun",
            "kerja"
        ],
        3: [
            "uang",
            "bank",
            "buat",
            "duit",
            "usaha",
            "masyarakat",
            "judol",
            "banyak",
            "kerja",
            "kredit"
        ],
        4: [
            "ekonomi",
            "indonesia",
            "rakyat",
            "baik",
            "purbaya",
            "investor",
            "negara",
            "asing",
            "banyak",
            "buat"
        ]
    };
    // Format topics with keywords
    const topTopics = Object.entries(topicCounts).sort(([, a], [, b])=>b - a).slice(0, 5).map(([topicIdStr, count])=>{
        const topicId = Number.parseInt(topicIdStr);
        return {
            id: topicId,
            label: `Topic ${String(topicId + 1).padStart(2, "0")}`,
            keywords: topicKeywordsMap[topicId] || [],
            count
        };
    });
    console.log("[v0] Top keywords:", topKeywords.length, topKeywords);
    console.log("[v0] Top topics:", topTopics.length, topTopics);
    // Get primary sentiment percentage
    const primarySentiment = sentimentData.positive?.pct || 0;
    // Get dominant emotion percentage
    const dominantEmotion = Math.max(...Object.values(emotionData).map((e)=>e.pct));
    return {
        totalComments,
        avgLength: Math.round(avgLength),
        primarySentiment,
        dominantEmotion,
        sentiment: sentimentData,
        emotion: emotionData,
        keywords: topKeywords,
        topics: topTopics
    };
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__6a86983b._.js.map