// purbaya-analytics/app/about/page.tsx
import AboutSection from "../../components/about-section";

export default function AboutPage() {
  return (
    <div className="container">
      <AboutSection />
    </div>
  );
}